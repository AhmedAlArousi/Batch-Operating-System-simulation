public enum ProcessState
{
Ready, New,Waiting,Running,Terminated 
}
