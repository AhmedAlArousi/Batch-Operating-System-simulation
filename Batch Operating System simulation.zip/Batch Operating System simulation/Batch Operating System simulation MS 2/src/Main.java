public class Main {
    public static void main(String[] args) {
        batchOS OS = new batchOS();
        OS.simulate();
    }
}
