
public enum process_state {
	READY, NEW, RUNNING, BLOCKED, FINISHED;
}
